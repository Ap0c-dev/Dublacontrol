const API_BASE_URL = 'https://nonalcoholic-boastfully-bryson.ngrok-free.dev/api/v1';

interface ApiResponse<T> {
  success: boolean;
  data: T;
  count?: number;
  error?: string;
  message?: string;
}

interface LoginResponse {
  success: boolean;
  token: string;
  user: {
    id: number;
    username: string;
    nome: string;
  };
  message?: string;
  error?: string;
}

interface DashboardStats {
  total_alunos: number;
  total_professores: number;
  total_pagamentos: number;
  pagamentos_pendentes: number;
  receita_mensal: number;
}

interface Aluno {
  id: number;
  nome: string;
  email: string;
  telefone: string;
  data_nascimento: string;
  status: string;
  created_at: string;
}

interface Professor {
  id: number;
  nome: string;
  email: string;
  especialidade: string;
  status: string;
}

interface Pagamento {
  id: number;
  aluno_id: number;
  aluno_nome: string;
  valor: number;
  data_vencimento: string;
  data_pagamento: string | null;
  status: string;
}

class ApiClient {
  private getToken(): string | null {
    return localStorage.getItem('token');
  }

  private getHeaders(): HeadersInit {
    const token = this.getToken();
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }

  async login(username: string, password: string): Promise<LoginResponse> {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    
    if (data.success && data.token) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
    }
    
    return data;
  }

  async logout(): Promise<void> {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }

  async getMe(): Promise<ApiResponse<{ id: number; username: string; nome: string }>> {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  async getDashboardStats(): Promise<ApiResponse<DashboardStats>> {
    const response = await fetch(`${API_BASE_URL}/dashboard/stats`, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  async getAlunos(filters?: { search?: string; status?: string }): Promise<ApiResponse<Aluno[]>> {
    const params = new URLSearchParams();
    if (filters?.search) params.append('search', filters.search);
    if (filters?.status) params.append('status', filters.status);
    
    const url = `${API_BASE_URL}/alunos${params.toString() ? `?${params}` : ''}`;
    const response = await fetch(url, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  async getAluno(id: number): Promise<ApiResponse<Aluno>> {
    const response = await fetch(`${API_BASE_URL}/alunos/${id}`, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  async getProfessores(): Promise<ApiResponse<Professor[]>> {
    const response = await fetch(`${API_BASE_URL}/professores`, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  async getPagamentos(filters?: { status?: string; aluno_id?: number }): Promise<ApiResponse<Pagamento[]>> {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.aluno_id) params.append('aluno_id', filters.aluno_id.toString());
    
    const url = `${API_BASE_URL}/pagamentos${params.toString() ? `?${params}` : ''}`;
    const response = await fetch(url, {
      headers: this.getHeaders(),
    });
    return response.json();
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  getUser(): { id: number; username: string; nome: string } | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}

export const api = new ApiClient();
export type { Aluno, Professor, Pagamento, DashboardStats, LoginResponse, ApiResponse };
