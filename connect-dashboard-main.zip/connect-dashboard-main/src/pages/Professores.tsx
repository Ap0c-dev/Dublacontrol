import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { api, Professor } from '@/lib/api';
import { Badge } from '@/components/ui/badge';
import { Loader2, GraduationCap, Mail } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function Professores() {
  const [professores, setProfessores] = useState<Professor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchProfessores = async () => {
      try {
        const response = await api.getProfessores();
        if (response.success) {
          setProfessores(response.data);
        } else {
          toast({
            title: 'Erro ao carregar professores',
            description: 'Não foi possível obter a lista.',
            variant: 'destructive',
          });
        }
      } catch (error) {
        toast({
          title: 'Erro de conexão',
          description: 'Verifique se o servidor está rodando.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfessores();
  }, [toast]);

  const getStatusBadge = (status: string) => {
    const isAtivo = status.toLowerCase() === 'ativo';
    return (
      <Badge 
        variant={isAtivo ? 'default' : 'secondary'}
        className={cn(
          isAtivo && 'bg-success/10 text-success border-success/20 hover:bg-success/20'
        )}
      >
        {isAtivo ? 'Ativo' : 'Inativo'}
      </Badge>
    );
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="animate-fade-in">
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Professores</h1>
          <p className="text-muted-foreground mt-1">
            Quadro de professores da instituição
          </p>
        </div>

        {/* Cards Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : professores.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {professores.map((professor, index) => (
              <div
                key={professor.id}
                className="bg-card rounded-xl border border-border p-6 shadow-card hover:shadow-card-hover transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-lg font-semibold text-primary">
                      {professor.nome?.charAt(0).toUpperCase() || 'P'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <h3 className="font-semibold text-foreground truncate">
                        {professor.nome}
                      </h3>
                      {getStatusBadge(professor.status)}
                    </div>
                    <div className="space-y-2">
                      {professor.especialidade && (
                        <p className="text-sm text-primary font-medium">
                          {professor.especialidade}
                        </p>
                      )}
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Mail size={14} />
                        <span className="truncate">{professor.email}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-card rounded-xl border border-border">
            <GraduationCap className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhum professor cadastrado.</p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
